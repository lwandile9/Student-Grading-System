package student.grading.system;

import java.util.Scanner;

/**
 * @author Lwandile.Toto
 */
public class StudentGradingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
              
   Scanner scanner = new Scanner(System.in);

        System.out.print("Enter instructor's name: ");
        String instructorName = scanner.nextLine();
        System.out.print("Enter instructor's age: ");
        int instructorAge = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter instructor's ID: ");
        String instructorID = scanner.nextLine();
        Instructor instructor = new Instructor(instructorName, instructorAge, instructorID);

        System.out.print("Enter course name: ");
        String courseName = scanner.nextLine();
        Course course = new Course(courseName, instructor);

        System.out.print("Enter number of students to enroll: ");
        int numStudents = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter student's name: ");
            String studentName = scanner.nextLine();
            System.out.print("Enter student's age: ");
            int studentAge = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter student's ID: ");
            String studentID = scanner.nextLine();

            Student student = new Student(studentName, studentAge, studentID);
            course.addStudent(student);

            System.out.print("Enter number of grades for this student: ");
            int numGrades = scanner.nextInt();
            for (int j = 0; j < numGrades; j++) {
                System.out.print("Enter grade: ");
                double grade = scanner.nextDouble();
                student.addGrade(grade);
            }
            scanner.nextLine();
        }

        course.displayCourseInfo();
        scanner.close();
    }
}
